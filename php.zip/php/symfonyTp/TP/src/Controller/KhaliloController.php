<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class KhaliloController extends AbstractController
{
    #[Route('/khalilo', name: 'app_khalilo')]
    public function index(): Response
    {
        return $this->render('khalilo/index.html.twig', [
            'controller_name' => 'KhaliloController',
        ]);
    }
}
