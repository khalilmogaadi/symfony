<?php

namespace App\Form;

use App\Entity\Borrowing;


use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;

class BorrowingType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('dateBorrowed',DateTimeType::class
            ,[
            'widget' => 'single_text',
            'attr'=> [
            'style'=>'width:400px' ,
            'class'=>"from-controlle mb-3 col-xs-" ,
             'date_format'=>'dd-MM-yyyy' ,
            ], 
             ])
            ->add('bookReturned')
            ->add('student')
            ->add('book')
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Borrowing::class,
        ]);
    }
}
